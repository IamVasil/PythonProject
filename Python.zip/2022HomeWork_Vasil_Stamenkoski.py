#1.Write a function to find the average of a list of integers.
def find_average(x):
    sum_of_list = 0
    for i in range(len(x)):
        sum_of_list += x[i]
    average = sum_of_list/len(x)
    return average
x = [2, 4, 1, 3, 3, 6, 7, 2, 8, 10]
average = find_average(x)
print("Avg od listata e = ",average)
#1.1Then, write another function to return all values from the list that are greater than the average.
def greater_than_avg(x):
    new_list = []
    for i in x:
        if i > average:
            new_list.append(i)
    return new_list

gta = greater_than_avg(x)
print("Pogolemi od prosekot se: ",gta)


#Exercise 2
#Creat a login screen for a user to enter credentials and create an account.
# Since we do not work here with libraries that provide graphics, the login screen is only questions for a username and a password.
# Below you will find how the user inputs the credentials.
#The username should only consist of letters and numbers and should be a minimum length of 4.
# The password can have all characters and should be minimum length of 8 and maximum length of 16.

class Account():
    def __init__(self, username, password):
        self.username = username
        self.password = password

        if len(username) == 4:
            print("Good username")
        else:
            print("Username is longer than expected")

        if len(password) > 8 and len(password) < 16:
            print("Good password")
        else:
            print("Password too short")

    def login(self, username, password):
        self.username = input("Enter username: ")
        self.password = input("Enter password: ")
        if username == username and password == password:
                print("login successful!")

    def register(self, username, password):
        self.username = input("Enter username: ")
        self.password = input("Enter password: ")
        self.pass_check = input("Enter password: ")


        if password == pass_check:
            print("Password match, you can login")
        else:
            print("passwords don't match")

#Bonus Exercise 3
def check(expression):
    lista = [" "]
    brackets = {"(": ")", "[": "]", "{": "}"}
    for c in expression:
        if c in brackets:
            lista.append(brackets[c])
        elif c in brackets.values() and c != lista.pop():
            return False
    return lista == [" "]

print(check("((5+3)*2+1)") == True)
print(check("{[(3+1)+2]+}") == True)
print(check("(3+{1-1)}") == False)
print(check("[1+1]+(2*2)-{3/3}") == True)
print(check("(({[(((1)-2)+3)-3]/3}-3)") == False)
print(check("[(3)+(-1)]*{3}") == True)
print(check("(((([[[{{{3}}}]]]]))))") == False)
print(check("[1+202]*3*({4+3)}") == False)
print(check("({[3]})-[4/(3*{1001-1000}*3)/4]") == True)
print(check("[[[1+[1+1]]])") == False)
print(check("(((1+(1+1))))]") == False)
print(check("2+3") == True)
